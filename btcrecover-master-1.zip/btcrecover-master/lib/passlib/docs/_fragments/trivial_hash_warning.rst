.. rst-class:: block-title

.. danger::

    **This algorithm is dangerously insecure by modern standards.**
    It is trivially broken, and should not be used if at all possible.
    For new code, see the list of :ref:`recommended hashes <recommended-hashes>`.

